from __future__ import annotations
import argparse, json, sys
from .config import Config
from .demo import demo_payload
from .service import run, render_text
from .storage import Store


def main(argv=None):
    p = argparse.ArgumentParser(prog="footprono")
    p.add_argument("--config"); p.add_argument("--db", default="footprono.db")
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("demo", help="écrit un fichier de données FICTIVES"); s.add_argument("--out", default="demo_fictif.json")
    s = sub.add_parser("analyze", help="analyse un fichier d'import 1xBet")
    s.add_argument("file"); s.add_argument("--window", type=int, default=120)
    s.add_argument("--mode", choices=["upcoming", "live", "both"], default="both")
    s.add_argument("--save", action="store_true"); s.add_argument("--json", action="store_true")
    s = sub.add_parser("settle", help="saisir le résultat final")
    s.add_argument("match_id"); s.add_argument("home_goals", type=int); s.add_argument("away_goals", type=int)
    s.add_argument("--next-goal", choices=["home", "away", "none"])
    s = sub.add_parser("void", help="marquer un match annulé"); s.add_argument("match_id")
    sub.add_parser("stats")
    s = sub.add_parser("serve"); s.add_argument("--host", default="127.0.0.1"); s.add_argument("--port", type=int, default=8000)
    a = p.parse_args(argv)
    cfg = Config.load(a.config)
    if a.cmd == "demo":
        json.dump(demo_payload(), open(a.out, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        print(f"Données fictives écrites dans {a.out}")
    elif a.cmd == "analyze":
        payload = json.load(open(a.file, encoding="utf-8"))
        res = run(payload, cfg, a.window, a.mode, a.db, a.save)
        print(json.dumps(res, ensure_ascii=False, indent=2) if a.json else render_text(res))
    elif a.cmd == "settle":
        n = Store(a.db).settle(a.match_id, a.home_goals, a.away_goals, a.next_goal)
        print(f"{n} pronostic(s) mis à jour")
    elif a.cmd == "void":
        Store(a.db).void(a.match_id); print("Pronostics marqués annulés")
    elif a.cmd == "stats":
        for r in Store(a.db).stats():
            print(r)
    elif a.cmd == "serve":
        from .web import serve
        serve(cfg, a.db, a.host, a.port)


if __name__ == "__main__":
    main()
