"""Tous les seuils sont ici et modifiables (config.json). Les valeurs par défaut
sont des HYPOTHÈSES à faire confirmer par le propriétaire (voir README)."""
from __future__ import annotations
import json
from dataclasses import dataclass, asdict


@dataclass
class Config:
    # --- Avant-match : régularité (logiques 1 et 2) ---
    sample_size: int = 5                 # nb de derniers matchs examinés
    slight_max_blanks: int = 1           # "légèrement régulière" = 1 match sans but max
    h2h_block_enabled: bool = True       # un adversaire avec + de victoires sans encaisser (H2H) bloque
    both_regular_total_line: float | None = None  # marché total si les 2 équipes sont régulières (None = non validé -> pas de pronostic)

    # --- Avant-match : seuils individuels (logique 3) ---
    threshold_sample_size: int = 5
    threshold_share: float = 0.8         # 80 % des matchs de l'échantillon
    thresholds: tuple = (3,)             # "moins de 3 buts" ; généralisable ex. (2, 3)
    range_low_offset: int = 1            # somme 5 -> fourchette 4-5
    range_high_offset: int = 0

    # --- Live ---
    live_min_minute: int = 18
    dominance_next_goal_ratio: float = 2.0   # strictement supérieur
    dominance_over_ratio: float = 1.8        # au moins
    min_dangerous_attacks: int = 8           # volume minimal pour l'équipe dominante (anti-ratios absurdes)
    over_requires_goalless: bool = True      # "plus de 0,5 but" seulement si 0-0
    underdog_rule_enabled: bool = True       # non-favori a marqué, favori 0
    live_max_age_seconds: int = 180          # stats plus vieilles = ignorées

    # --- Confiance ---
    confidence_min_sample: int = 30
    confidence_medium: float = 0.55
    confidence_high: float = 0.70

    @classmethod
    def load(cls, path: str | None) -> "Config":
        cfg = cls()
        if path:
            with open(path, encoding="utf-8") as f:
                raw = json.load(f)
            for k, v in raw.items():
                if not hasattr(cfg, k):
                    raise ValueError(f"Paramètre inconnu dans la config : {k}")
                setattr(cfg, k, tuple(v) if k == "thresholds" else v)
        return cfg

    def to_dict(self) -> dict:
        return asdict(self)
