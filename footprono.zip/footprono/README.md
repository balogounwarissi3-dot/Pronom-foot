# Analyse football — moteur de règles (prototype, étape 1)

Source de données prévue : **1xBet uniquement**. Aucun scraping contournant une protection, une connexion ou un CAPTCHA.
Tant qu'un accès autorisé n'est pas confirmé, les données se fournissent par **import manuel** (JSON, format ci-dessous).
La faisabilité d'une intégration automatique 1xBet n'a **pas été vérifiée** : à contrôler (API/partenariat officiel, conditions d'utilisation).

## Lancer
    python -m footprono demo                       # données FICTIVES -> demo_fictif.json
    python -m footprono analyze demo_fictif.json --window 120 --mode both --save
    python -m footprono settle D1 2 1              # résultat final (option --next-goal home|away|none)
    python -m footprono void D2                    # match annulé
    python -m footprono stats                      # réussites par logique / marché / compétition
    FOOTPRONO_TOKEN=secret python -m footprono serve --host 0.0.0.0   # interface mobile -> http://IP:8000/?token=secret
    python -m unittest discover -s tests           # 19 tests

Android : Termux (`pkg install python`) permet de tout lancer sur le téléphone, ou lancer `serve` sur un PC/serveur.

## Format d'import
    {"source":"1xBet (saisie manuelle)","collected_at":"2026-11-02T12:00:00Z","matches":[{
      "id":"123","competition":"...","home":"A","away":"B","status":"scheduled|live","kickoff":"ISO",
      "favorite":"home|away", "home_last_scored":[2,1,0,3,1], "away_last_scored":[...],   // du plus récent au plus ancien
      "h2h":[{"home":"A","away":"B","home_goals":1,"away_goals":0}],                      // facultatif
      "live":{"minute":30,"home_goals":0,"away_goals":0,"stats_at":"ISO",
              "home":{"dangerous_attacks":14,"shots_on_target":4,"shots_off_target":5},"away":{...}}}]}
Toute valeur absente/invalide n'est jamais remplacée : le match est ignoré avec la raison.

## Hypothèses à CONFIRMER (config : `config.py`, surchargeable par `--config config.json`)
1. Échantillon = 5 derniers matchs ; « légèrement régulière » = 1 match sans but max.
2. Logique 1 = régularité **stricte** + face-à-face (bloque si l'adversaire a plus de victoires sans encaisser) ; logique 2 = tolérance d'une exception.
3. Deux équipes régulières : **aucun pronostic** tant que le marché total n'est pas validé (`both_regular_total_line`).
4. Logique 3 : seuil « < 3 » à 80 % ; somme S -> fourchette S-1 à S (ex. 5 -> 4–5). Une seule équipe avec seuil = pas de pronostic. Avec « moins de 3 » chaque, la somme vaut 6 : à clarifier.
5. Live : à partir de la 18e minute ; > 2× strict -> prochain but ; ≥ 1,8× -> plus de 0,5 but seulement si 0-0 ; volume minimal de 8 attaques dangereuses ; stats de plus de 3 min ignorées ; priorité prochain but > over 0,5 > règle non-favori.
6. Règle non-favori : sans seuil de minute ; le favori doit être fourni dans l'import.
7. Confiance : « non évaluée » sous 30 résultats ; ensuite faible/moyenne/élevée à 55 % / 70 %.
8. Libellés de marchés à faire correspondre aux marchés réels de 1xBet.

## Reste à faire (étapes suivantes du cahier)
Intégration 1xBet autorisée (si possible), couche IA explicative facultative, migration Supabase/PostgreSQL, saisie des résultats depuis l'interface.
